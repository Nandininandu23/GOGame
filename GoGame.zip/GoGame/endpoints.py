from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

class Go(BaseModel):
    board_size: int = 19
    board: list[list[int]] = [[0 for _ in range(board_size)] for _ in range(board_size)]
    turn: int = 1
    move_history: list[tuple[list[list[int]], int]] = []

    def place_stone(self, row: int, col: int) -> None:
        if self.board[row][col] != 0:
            raise HTTPException(status_code=400, detail="Intersection is already occupied.")

        if self.is_ko(row, col):
            raise HTTPException(status_code=400, detail="Invalid move: rule of ko")

        self.board[row][col] = self.turn
        self.move_history.append((self.board.copy(), self.turn))
        self.turn = 3 - self.turn
        self.remove_dead_stones()

    def is_ko(self, row: int, col: int) -> bool:
        if not self.move_history:
            return False
        last_board, last_turn = self.move_history[-1]
        if last_turn == self.turn:
            return False
        new_board = [row[:] for row in self.board]
        new_board[row][col] = self.turn
        return new_board == last_board

    def remove_dead_stones(self) -> None:
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.board[r][c] == 0:
                    continue
                group, liberty = self.find_group_and_liberty(r, c)
                if liberty == 0:
                    self.remove_group(group)

    def find_group_and_liberty(self, row: int, col: int) -> tuple[set[tuple[int, int]], int]:
        color = self.board[row][col]
        group = set()
        liberty = set()
        visited = set()
        queue = [(row, col)]
        while queue:
            r, c = queue.pop()
            if (r, c) in visited:
                continue
            visited.add((r, c))
            if self.board[r][c] == color:
                group.add((r, c))
                for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < self.board_size and 0 <= nc < self.board_size:
                        if self.board[nr][nc] == 0:
                            liberty.add((nr, nc))
                        elif self.board[nr][nc] == color:
                            queue.append((nr, nc))
        return group, len(liberty)

    def remove_group(self, group: set[tuple[int, int]]) -> None:
        for r, c in group:
            self.board[r][c] = 0

    def count_territory(self) -> dict[int, int]:
        score = {1: 0, 2: 0}
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.board[r][c] == 0:
                    group, liberty = self.find_group_and_liberty(r, c)
                    if len(group) > 0:
                        color = list(group)[0]
                        score[color] += len(group)
        return score

@app.post("/place_stone/{row}/{col}")
def place_stone(row: int, col: int, game: Go):
    if game.board[row][col] != 0:
        return {"error": "Intersection is already occupied."}
    game.board[row][col] = game.turn
    game.turn = 3 - game.turn
    game.remove_dead_stones()
    return {"board": game.board, "turn": game.turn}

@app.get("/count_territory")
def count_territory(game: Go):
    score = game.count_territory()
    return {"score": score}