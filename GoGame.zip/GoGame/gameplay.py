


class Go:
    def __init__(self, board_size=19):
        self.board_size = board_size
        self.board = [[0 for _ in range(board_size)] for _ in range(board_size)]
        self.turn = 1

    def place_stone(self, row, col):
        if self.board[row][col] != 0:
            return False
        self.board[row][col] = self.turn
        self.turn = 3 - self.turn
        return True

    def remove_dead_stones(self):
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.board[r][c] == 0:
                    continue
                group, liberty = self.find_group_and_liberty(r, c)
                if liberty == 0:
                    self.remove_group(group)

    def find_group_and_liberty(self, row, col):
        color = self.board[row][col]
        group = set()
        liberty = set()
        visited = set()
        queue = [(row, col)]
        while queue:
            r, c = queue.pop()
            if (r, c) in visited:
                continue
            visited.add((r, c))
            if self.board[r][c] == color:
                group.add((r, c))
                for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < self.board_size and 0 <= nc < self.board_size:
                        if self.board[nr][nc] == 0:
                            liberty.add((nr, nc))
                        elif self.board[nr][nc] == color:
                            queue.append((nr, nc))
        return group, len(liberty)

    def remove_group(self, group):
        for r, c in group:
            self.board[r][c] = 0

    def count_territory(self):
        score = {1: 0, 2: 0}
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.board[r][c] == 0:
                    group, liberty = self.find_group_and_liberty(r, c)
                    if len(group) > 0:
                        color = list(group)[0]
                        score[color] += len(group)
        return score
